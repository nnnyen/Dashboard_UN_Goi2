#install.packages("Rilostat")
if(!require(devtools)){install.packages('devtools')}
library(devtools)
#install_github("ilostat/Rilostat")
library(Rilostat)
#install.packages("countrycode")
library(countrycode)
library(dplyr)
library(ggplot2)
library(ggrepel)
library(scales)
library(plotly)
library(shiny)

toc <-get_ilostat_toc(search = 'Employment by sex and age')
employ <- get_ilostat("EMP_2EMP_SEX_AGE_NB_A") %>%
  rename(Country = ref_area) %>%
  rename(Sex = sex) %>%
  mutate(Sex = case_when(
    Sex == "SEX_M" ~ "Male",
    Sex == "SEX_F" ~ "Female",
    TRUE ~ Sex
  )) %>%
  filter(Sex %in% c("Male", "Female")) %>%
  rename(Age = classif1) %>%
  filter(Age == "AGE_YTHADULT_YGE15") %>%
  rename(Year = time) %>%
  filter(Year >= 2000 & Year <= 2022) %>%
  rename(Employment = obs_value) %>%
  select(Country, Sex, Year, Employment) %>%
  arrange(Country, desc(Year)) %>%
  mutate(Country = countrycode(Country, "iso3c", "country.name"))
employ <- employ %>% filter(!is.na(Country))
employ$Region <- countrycode(employ$Country, "country.name", "region")
employ <- employ %>% mutate(Region = ifelse(Country == "Western Sahara", "Middle East & North Africa", Region))
missing_values <- colSums(is.null(employ) | is.na(employ))
employ <- employ %>%
  group_by(Region) %>%
  mutate(nums_country_region = n_distinct(Country))
# Tạo dataframe mới từ dữ liệu "employ" với các cột chỉ định
dfe <- employ %>%
  select(Country, Year, Sex, Employment, Region) %>%
  group_by(Country, Year, Region) %>%
  summarise(Employment = sum(ifelse(Sex == "Female", Employment, 0)) / sum(ifelse(Sex == "Male", Employment, 0)))
dfe <- dfe %>%
  left_join(employ %>% filter(Sex == "Female") %>% select(Country, Year, Employment), by = c("Country", "Year", "Region")) %>%
  rename(Employment = Employment.x) %>%
  mutate(TotalEmployment = ifelse(!is.na(Employment.y), Employment.y, 0)) %>%
  select(-Employment.y)
 
# Tổng số lượng việc làm của Female theo từng khu vực và năm
employ_region <- employ %>%
  group_by(Region, Year) %>%
  summarize(TotalEmployment = sum(Employment, na.rm = TRUE))
ggplot(employ_region, aes(x = Year, y = TotalEmployment, group = Region, color = Region)) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  labs(x = "Năm", y = "Tổng số lượng việc làm (Female)", color = "Khu vực") +
  scale_x_discrete(breaks = c("2000", "2005", "2010", "2015", "2020")) +
  theme(legend.position = "top")

#Số lượng phụ nữ có việc làm của các quốc gia thuộc khu vực East Asia & Pacific
options(repr.plot.width = 6, repr.plot.height = 14)  
ggplot(dfe %>% filter(Region == "East Asia & Pacific"), aes(x = TotalEmployment, y = Country)) +
  geom_bar(stat = "identity", fill = "lightpink") +
  labs(title = "Tổng số việc làm (Female) ở Đông Á và Thái Bình Dương") +
  labs(x = "Tổng số việc làm", y = "Quốc gia") +
  theme(axis.text.x = element_text(angle = 90, hjust = 0.5))

#Tương quan của GDP với Employment
ratedf <- merge(merge(dfe, dfgdp, by = c("Country", "Year"), all = TRUE), 
                dfgen, by = c("Country", "Year"), all = TRUE)
ratedf <- na.omit(ratedf)
top_country_2000 <- ratedf %>%
  filter(Year == 2000) %>%
  arrange(desc(Employment)) %>%
  slice(1)
top_country_2022 <- ratedf %>%
  filter(Year == 2022) %>%
  arrange(desc(Employment)) %>%
  slice(1)
ratedf %>%
  filter(Year == 2000 | Year == 2022) %>%
  mutate(pop_m = Gender / 1e6) %>%
  ggplot(aes(x = GDP, y = Employment)) +
  geom_point(aes(size = pop_m, color = Region), alpha = 0.5) +
  geom_smooth(method = "auto") +
  scale_x_continuous(labels = comma) +
  labs(title = 'Tỷ lệ việc làm của Nữ và GDP của các quốc gia năm 2000 và 2022') +
  labs(x = "GDP ($/Năm)", y = "Tỷ lệ việc làm của Nữ (%)") +
  labs(color = "Khu vực", size = "Dân số (Triệu người)") +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_grid(Year~.)+
  geom_text_repel(data = top_country_2000, aes(label = Country), nudge_x = 5000, nudge_y = -5) +
  geom_text_repel(data = top_country_2022, aes(label = Country), nudge_x = 5000, nudge_y = -5)


# World Map
world_map <- map_data("world")
mapemp <- subset(dfe, Year =="2022")
p <- plot_ly(mapemp, z = ~Employment, text = ~paste("Country: ", Country, "<br>Employment: ", Employment),
             locations = ~Country, type = "choropleth", locationmode = "country names")
p <- layout(p, geo = list(scope = "world"))
p
chart_em <- employ %>%
  select(Country, time, sex, Employment,Region) %>%
  group_by(Country, time,Region) %>%
  summarise(Employment = sum(ifelse(sex == "Female", Employment, 0)) / sum(ifelse(sex == "Male", Employment, 0)))
colnames(chart_em)[2] <- "Year"

