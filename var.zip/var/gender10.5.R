#install.packages("countrycode")
library(countrycode)
#install.packages("dplyr")
library(dplyr)
#install.packages("xml2")
library(xml2)
#install.packages("rvest")
library(rvest)
base_url <- "https://data.un.org/Data.aspx?d=POP&f=tableCode%3a1%3brefYear%3a2000%2c2001%2c2002%2c2003%2c2004%2c2005%2c2006%2c2007%2c2008%2c2009%2c2010%2c2011%2c2012%2c2013%2c2014%2c2015%2c2016%2c2017%2c2018%2c2019%2c2020%2c2021%2c2022%3bareaCode%3a0%3bsexCode%3a1%2c2&c=2,3,6,8,10,12,13,14&s=_countryEnglishNameOrderBy:asc,refYear:desc,areaCode:asc&v="

data_part_2 <- data.frame()  # Khởi tạo data frame rỗng

for (i in 1:50) {
  url <- paste0(base_url, i)
  page <- read_html(url)
  
  # Trích xuất dữ liệu từ phần tử HTML (điều chỉnh CSS selector theo yêu cầu)
  dataset_df <- page %>%
    html_nodes("table") %>%
    html_table(fill = TRUE)
  
  # Gộp dữ liệu vào data frame chính
  if (!is.null(dataset_df[[2]])) {
    data_part_2 <- rbind(data_part_2, dataset_df[[2]])
  }
}

for (i in 51:100) {
  url <- paste0(base_url, i)
  page <- read_html(url)
  
  # Trích xuất dữ liệu từ phần tử HTML (điều chỉnh CSS selector theo yêu cầu)
  dataset_df <- page %>%
    html_nodes("table") %>%
    html_table(fill = TRUE)
  
  # Gộp dữ liệu vào data frame chính
  if (!is.null(dataset_df[[2]])) {
    data_part_2 <- rbind(data_part_2, dataset_df[[2]])
  }
}

for (i in 101:153) {
  url <- paste0(base_url, i)
  page <- read_html(url)
  
  # Trích xuất dữ liệu từ phần tử HTML (điều chỉnh CSS selector theo yêu cầu)
  dataset_df <- page %>%
    html_nodes("table") %>%
    html_table(fill = TRUE)
  
  # Gộp dữ liệu vào data frame chính
  if (!is.null(dataset_df[[2]])) {
    data_part_2 <- rbind(data_part_2, dataset_df[[2]])
  }
}
for (i in 154:200) {
  url <- paste0(base_url, i)
  page <- read_html(url)
  
  # Trích xuất dữ liệu từ phần tử HTML (điều chỉnh CSS selector theo yêu cầu)
  dataset_df <- page %>%
    html_nodes("table") %>%
    html_table(fill = TRUE)
  
  # Gộp dữ liệu vào data frame chính
  if (!is.null(dataset_df[[2]])) {
    data_part_2 <- rbind(data_part_2, dataset_df[[2]])
  }
}

for (i in 201:230) {
  url <- paste0(base_url, i)
  page <- read_html(url)
  
  # Trích xuất dữ liệu từ phần tử HTML (điều chỉnh CSS selector theo yêu cầu)
  dataset_df <- page %>%
    html_nodes("table") %>%
    html_table(fill = TRUE)
  
  # Gộp dữ liệu vào data frame chính
  if (!is.null(dataset_df[[2]])) {
    data_part_2 <- rbind(data_part_2, dataset_df[[2]])
  }
}
genderdf <- data_part_2
#Xử lí genderdf
genderdf <- genderdf[, -c(3,5:7,9)]
colnames(genderdf)[colnames(genderdf) == "Value"] <- "Gender"
colnames(genderdf)[colnames(genderdf) == "Country or Area"] <- "Country"
head(genderdf,5)

newdf <- genderdf[, -3]
head(newdf, 5)

genderdf <- data_part_2
genderdf <- genderdf[, -c(3,5:7,9)]
colnames(genderdf)[colnames(genderdf) == "Value"] <- "Gender"
head(genderdf,5)

genderdf1 <- data.frame(genderdf)
#Kiểm tra liệu có giá trị null hay na
column_names <- names(genderdf1)
print(column_names)

for (col_name in column_names) {
  num_null <- sum(is.null(genderdf1[[col_name]]))
  num_na <- sum(is.na(genderdf1[[col_name]]))
  
  print(paste("Column:", col_name))
  print(paste("Number of null:", num_null))
  print(paste("Number of NA:", num_na))
  print("")
}
library(countrycode)

genderdf$Country <- genderdf$`Country or Area`
genderdf11 <- data.frame(genderdf1)
genderdf11$Region <- countrycode(genderdf11$Country, "country.name", "region")

genderdf11$Region <- ifelse(genderdf11$Country %in% c("Mayotte", "Reunion"), "Sub-Saharan Africa", genderdf11$Region)
genderdf11$Region <- ifelse(genderdf11$Country %in% c("Saint Helena ex. dep.", "Saint Helena: Ascension", "Saint Helena: Tristan da Cunha"), "Sub-Saharan Africa", genderdf11$Region)
genderdf11$Region <- ifelse(genderdf11$Country %in% c("Wallis and Futuna Islands"), "East Asia & Pacific", genderdf11$Region)

library(dplyr)
grouped_genderdf11 <- genderdf11 %>%
  group_by(Region) %>%
  summarize(Num_Countries = n())

print(grouped_genderdf11)
merged_genderdf <- left_join(genderdf11, grouped_genderdf11, by = "Region")
merged_genderdf

merged_genderdf <- merged_genderdf %>%
  mutate(Gender = gsub(",", "", Gender)) %>%
  mutate(Gender = as.numeric(Gender))

str(merged_genderdf)
summary(merged_genderdf)

gender_male <- filter(merged_genderdf, Sex == "Male")
head(gender_male)

gender_female <- filter(merged_genderdf, Sex == "Female")
head(gender_female)

gender_dffull <- rbind(gender_male, gender_female)
gender_region <- gender_dffull[, c("Region", "Year", "Sex", "Gender")]

library(tidyverse)
male <- gender_region%>%
  group_by(Region, Year, Sex = "Female") %>%
  summarise(Gender = sum(Gender))
ggplot(male,
       aes(x = Gender,
           y = factor(Region))) +
  geom_col(fill = "coral1")

female <- gender_region %>%
  group_by(Region, Year, Sex = "Female") %>%
  summarise(Gender = sum(Gender))
ggplot(female,
       aes(x = -Gender,
           y = factor(Region))) +
  geom_col(fill = "aquamarine3")

male_female <- filter(gender_region, Year == 2021)
male_female_pyramid <- male_female %>%
  group_by(Region, Year, Sex) %>%
  summarise(Gender = sum(Gender)) %>%
  mutate(
    Gender = case_when(
      Sex == "Female" ~ -Gender,
      TRUE ~ Gender
    ),
    Region = as_factor(Region)
  ) %>%
  mutate(Gender = Gender / 1e6)
male_female_pyramid

library(ggplot2)

ggplot(male_female_pyramid,
       aes(x = Gender,
           y = Region,
           fill = Sex)) +
  geom_col() +
  geom_text(data = subset(male_female_pyramid, Sex == "Female"),
            aes(label = Gender),
            position = position_nudge(x = -0.05, y = 0),
            size = 3) +
  geom_text(data = subset(male_female_pyramid, Sex == "Male"),
            aes(label = Gender),
            position = position_nudge(x = 0.05, y = 0),
            size = 3) +
  theme(text = element_text(size = 4))

#East Asia & Pacific
gender_country <- filter(gender_dffull, Region == "East Asia & Pacific", Year == "2021")
print(gender_country)

filtered_data <- gender_dffull %>%
  filter(Region == "East Asia & Pacific", Year == "2021") %>%
  group_by(Country.or.Area, Year, Sex) %>%
  summarise(Gender = sum(Gender))

print(filtered_data)

summary(filtered_data)

ggplot(filtered_data, aes(x = Country.or.Area, y = Gender, fill = Sex)) +
  geom_col(position = "dodge") +
  labs(title = "Gender Distribution in East Asia & Pacific (2021)", x = "Country", y = "Gender") +
  scale_fill_manual(values = c("#1f77b4", "#ff7f0e"), labels = c("Male", "Female")) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

#QG CÓ GEN NHỎ HƠN SING
singapore_gender <- filtered_data %>%
  filter(Country.or.Area == "Singapore") %>%
  pull(Gender)

lowerthanSing <- filtered_data %>%
  filter(Gender < singapore_gender) %>%
  select(Country.or.Area, Year, Sex, Gender)

print(lowerthanSing)

#Europe & Central Asia
EuropeCentralAsia <- filter(gender_dffull, Region == "Europe & Central Asia", Year == "2021")
print(EuropeCentralAsia)

EuropeCentralAsia <- gender_dffull %>%
  filter(Region == "Europe & Central Asia", Year == "2021") %>%
  group_by(Country.or.Area, Year, Sex) %>%
  summarise(Gender = sum(Gender))

print(EuropeCentralAsia)

ggplot(EuropeCentralAsia, aes(x = Country.or.Area, y = Gender, fill = Sex)) +
  geom_col(position = "dodge") +
  labs(title = "Gender Distribution in Europe Central Asia (2021)", x = "Country", y = "Gender") +
  scale_fill_manual(values = c("#1f77b4", "#ff7f0e"), labels = c("Male", "Female")) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

#Latin America & Caribbean
LatinAmericaCaribbean <- filter(gender_dffull, Region == "Latin America & Caribbean", Year == "2021")
print(LatinAmericaCaribbean)

LatinAmericaCaribbean <- gender_dffull %>%
  filter(Region == "Latin America & Caribbean", Year == "2021") %>%
  group_by(Country.or.Area, Year, Sex) %>%
  summarise(Gender = sum(Gender))

print(LatinAmericaCaribbean)

ggplot(LatinAmericaCaribbean, aes(x = Country.or.Area, y = Gender, fill = Sex)) +
  geom_col(position = "dodge") +
  labs(title = "Gender Distribution in Latin America & Caribbean (2021)", x = "Country", y = "Gender") +
  scale_fill_manual(values = c("#1f77b4", "#ff7f0e"), labels = c("Male", "Female")) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

#Middle East & North Africa
MiddleEastNorthAfrica <- filter(gender_dffull, Region == "Middle East & North Africa", Year == "2021")
print(LatinAmericaCaribbean)

MiddleEastNorthAfrica <- gender_dffull %>%
  filter(Region == "Middle East & North Africa", Year == "2021") %>%
  group_by(Country.or.Area, Year, Sex) %>%
  summarise(Gender = sum(Gender))

print(MiddleEastNorthAfrica)

ggplot(MiddleEastNorthAfrica, aes(x = Country.or.Area, y = Gender, fill = Sex)) +
  geom_col(position = "dodge") +
  labs(title = "Gender Distribution in Middle East & North Africa (2021)", x = "Country", y = "Gender") +
  scale_fill_manual(values = c("#1f77b4", "#ff7f0e"), labels = c("Male", "Female")) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

#North America
NorthAmerica <- filter(gender_dffull, Region == "North America", Year == "2021")
print(NorthAmerica)

NorthAmerica <- gender_dffull %>%
  filter(Region == "North America", Year == "2021") %>%
  group_by(Country.or.Area, Year, Sex) %>%
  summarise(Gender = sum(Gender))

print(NorthAmerica)

ggplot(NorthAmerica, aes(x = Country.or.Area, y = Gender, fill = Sex)) +
  geom_col(position = "dodge") +
  labs(title = "Gender Distribution in North America (2021)", x = "Country", y = "Gender") +
  scale_fill_manual(values = c("#1f77b4", "#ff7f0e"), labels = c("Male", "Female")) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

#South Asia
SouthAsia <- filter(gender_dffull, Region == "South Asia", Year == "2021")
print(SouthAsia)

SouthAsia <- gender_dffull %>%
  filter(Region == "South Asia", Year == "2021") %>%
  group_by(Country.or.Area, Year, Sex) %>%
  summarise(Gender = sum(Gender))

print(SouthAsia)

ggplot(SouthAsia, aes(x = Country.or.Area, y = Gender, fill = Sex)) +
  geom_col(position = "dodge") +
  labs(title = "Gender Distribution in South Asia (2021)", x = "Country", y = "Gender") +
  scale_fill_manual(values = c("#1f77b4", "#ff7f0e"), labels = c("Male", "Female")) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

#Sub-Saharan Africa
SubSaharanAfrica <- filter(gender_dffull, Region == "Sub-Saharan Africa", Year == "2021")
print(SubSaharanAfrica)

SubSaharanAfrica <- gender_dffull %>%
  filter(Region == "Sub-Saharan Africa", Year == "2021") %>%
  group_by(Country.or.Area, Year, Sex) %>%
  summarise(Gender = sum(Gender))

print(SubSaharanAfrica)

ggplot(SubSaharanAfrica, aes(x = Country.or.Area, y = Gender, fill = Sex)) +
  geom_col(position = "dodge") +
  labs(title = "Gender Distribution in Sub-Saharan Africa (2021)", x = "Country", y = "Gender") +
  scale_fill_manual(values = c("#1f77b4", "#ff7f0e"), labels = c("Male", "Female")) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

#5 QUỐC GIA CÓ FEMALE CAO NHẤT THẾ GIỚI
female_counts <- merged_genderdf %>%
  filter(Sex == "Female") %>%
  group_by(Country.or.Area) %>%
  summarize(Total_Females = sum(Gender))
female_counts <- female_counts %>%
  arrange(desc(Total_Females))
top_countries <- head(female_counts, 5)
chart <- ggplot(top_countries, aes(x = Country.or.Area, y = Total_Females)) +
  geom_col(fill = "coral2") +
  geom_text(aes(label = Total_Females), vjust = -0.5, color = "black", size = 3.5) +
  labs(title = "Top 5 Countries with Highest Number of Females", x = "Country", y = "Total Females")

print(chart)

library(plotly)
library(ggplot2)
library(shiny)

#WORLD MAP 
world_map <- map_data("world")

mapseat <- subset(merged_genderdf, Year =="2020")

p <- plot_ly(merged_genderdf, z = ~Gender, text = ~paste("Country: ", Country.or.Area, "<br>Female: ", Gender),
             locations = ~Country.or.Area, type = "choropleth", locationmode = "country names") %>%
  layout(geo = list(scope = "world"))

p

chart_gen <- merged_genderdf[merged_genderdf$Sex == "Female", c("Country", "Year", "Gender","Region")]

